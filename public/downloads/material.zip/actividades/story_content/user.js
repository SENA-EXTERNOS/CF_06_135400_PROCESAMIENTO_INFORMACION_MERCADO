function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6J51M8J86xI":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

